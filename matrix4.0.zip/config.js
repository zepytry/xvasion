const fs = require('fs')


// ━━━━ CHANGE OWNER NUMBER (しなければならない)
global.owner = "6289602190311"












































// ━━━━ DO NOT CHANGE (しなければならない)
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
